
function howMuchLeftOverCake() {
    var slicesOfCake = 12
    var numberOfPeople = 5
    var remainingNumberOfSlices = slicesOfCake % numberOfPeople
    if (remainingNumberOfSlices == 0) {
        console.log("No leftovers for you!");
    }
    else if (remainingNumberOfSlices <= 2) {
        console.log("You have some leftovers.");
    }
    else if (3 <= remainingNumberOfSlices <= 5) {
        console.log("You have leftovers to share.");
    }
    else {
        console.log("Have another party!");
    }
}
howMuchLeftOverCake()