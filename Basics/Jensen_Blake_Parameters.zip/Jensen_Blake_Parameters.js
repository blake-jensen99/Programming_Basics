function starWarsGreeting(person, time) {
    if (person == "General Grevious" && time == "Morning") {
        console.log('Hello there and good morning.');
    }
    else if (person == "Count Dooku" && time == "Night") {
        console.log("I'm coming for you later tonight, Dooku!");
    }
}

starWarsGreeting("General Grevious", "Morning")
starWarsGreeting("Count Dooku", "Night")

