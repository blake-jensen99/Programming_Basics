// variables to be used to determine rider eligibility

var min_height = 42; //inches
var min_age = 10;
var rider_height = 34;
var rider_age = 11;

if (rider_height >= min_height) {
    console.log("Get on that ride, kid!");
} else if (rider_age >= min_age) {
    console.log("Get on that ride, kid!");
} else {
    console.log("Sorry kiddo. Maybe next year.");
}
