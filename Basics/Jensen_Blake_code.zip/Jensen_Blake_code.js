// Shows the number of likes
var likeCount = 0;
// Function's purpose is to increase the number of likes within the 'likeCount' variable
function increaseLikes() {
    // Increases the the 'likeCount' variable by 1
    likeCount = likeCount + 1;
}
